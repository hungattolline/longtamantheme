<?php

defined('ABSPATH') || defined('DUPXABSPATH') || exit;
?>
<tr>
    <td>With this mode,Archive Action</td>
    <td>
        <b>Extract files over current files:</b><br/>
        The existing site files will be overwritten with the contents of the archive.zip/daf.

        <br/>
        <br/>

        <b>Remove WP core and content and extract:</b><br/>
        The existing WordPress core files and WordPress Content directory will be removed, and then the archive will be extracted.
        
        <br/>
        <br/>

        <b>Remove all files except addon sites and extract:</b><br/>
        All files except a addon site will be removed, and then the archive will be extracted.
        
        <br/>
        <br/>
    </td>
</tr>
