<?php

defined('ABSPATH') || defined('DUPXABSPATH') || exit;
?>
<tr>
    <td class="col-opt">Email Domains</td>
    <td>The domain portion of all email addresses will be updated if this option is enabled.</td>
</tr>