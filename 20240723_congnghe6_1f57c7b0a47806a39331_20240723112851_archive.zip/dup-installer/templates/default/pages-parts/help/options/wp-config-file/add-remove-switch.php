<?php

defined('ABSPATH') || defined('DUPXABSPATH') || exit;
?>
<tr>
    <td class="col-opt">Add/remove switch</td>
    <td>
        Each wp-config value has an associated switch that controls the insertion and removal of the constant.<br>
        If the switch is deactivated, the constant will be removed from wp-config.php
    </td>
</tr>