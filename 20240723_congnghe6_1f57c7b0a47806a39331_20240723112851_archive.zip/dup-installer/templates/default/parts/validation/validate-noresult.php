<?php

/**
 *
 * @package templates/default
 *
 */

defined('ABSPATH') || defined('DUPXABSPATH') || exit;
?>
<div id="validate-no-result" class="text-center" >
    <p><b><i class="far fa-check-circle"></i> Not validated yet, please click validate button.</b></p>
</div>